-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2016 at 04:57 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `csi`
--

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

DROP TABLE IF EXISTS `contents`;
CREATE TABLE IF NOT EXISTS `contents` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(11) NOT NULL,
  `headline` longtext COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `background` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `contents`
--

TRUNCATE TABLE `contents`;
--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `page_id`, `headline`, `description`, `image`, `created_at`, `updated_at`, `title`, `background`) VALUES
(1, 6, '<p style="line-height: 1;"><span style="font-size: 36px;"><font color="#f58220">The Begining is </font></span></p><p style="text-align: center; line-height: 1;"><span style="font-size: 160px;">Family</span></p>', '<p><br></p>', '', NULL, '2016-09-30 21:34:43', 'Family', 'public/images/background/home_family1.png'),
(2, 6, '<p style="line-height: 0.3;"><span style="font-size: 24px;"><font color="#f58220">We provide not only professional services</font></span></p><p style="line-height: 0.3;"><span style="font-size: 45px;"><font color="#f58220"><span style="font-size: 24px;">but also an integrated, competent and</span> </font></span>    <span style="font-size: 45px;"><font color="#ff9c00"> </font></span></p><p style="text-align: center; line-height: 1;"><span style="font-size: 130px;"><font color="#ffffff">Friendly<span style="font-size: 36px;">team</span></font></span></p>', '<p><font color="#f58220"><span style="font-size: 24px;">‘CSI Group’</span></font><span style="font-size: 24px;"> <span style="font-size: 18px;">is supported by a solid and tested working group. They are young professionals who are rich in experience and have a high working passion. They are able to understand and analyze what you need most, when and how to make it <span style="font-size: 24px;">happen</span>.</span></span></p>', '', NULL, '2016-09-30 21:35:01', 'Friendly', 'public/images/background/home_family2.png'),
(4, 6, '<p style="line-height: 0.3;"><span style="font-size: 24px;"><font color="#f58220">we give not only best achievements</font></span></p><p style="line-height: 0.3;"><span style="font-size: 45px;"><font color="#f58220"><span style="font-size: 24px;">but also a limitless creativity and</span></font></span></p><p style="line-height: 0.3;"><span style="font-size: 45px;"><font color="#f58220"><span style="font-size: 24px;"><br></span></font></span></p><p style="text-align: center; line-height: 1;"><span style="font-size: 130px;"><sup><span style="font-size: 36px; line-height: 0.5;">Bright </span></sup></span><span style="font-size: 36px;">﻿</span><span style="font-size: 130px;">ideas<span style="font-size: 36px;">team</span></span></p>', '<p><font color="#f58220"><span style="font-size: 24px;">Creativity</span></font>, <span style="font-size: 18px;">which become the sithe of  ‘CSI Group’, not only will deliver your brand to the top of popularity and embracing the success but also open the new horizon for every capable strategic plans formation as an effort to maintain the success in the <span style="font-size: 24px;">future</span>.</span></p>', '', '2016-09-22 09:06:12', '2016-09-30 21:35:16', 'Ideas', 'public/images/background/home_family3.png'),
(5, 6, '<p style="line-height: 0.3;"><span style="font-size: 24px;"><font color="#f58220">we serve not only various menu</font></span></p><p style="line-height: 0.3;"><span style="font-size: 45px;"><font color="#f58220"><span style="font-size: 24px;">but also scope and abundanta limitless creativity and</span></font></span></p><p style="line-height: 0.3;"><span style="font-size: 45px;"><font color="#f58220"><span style="font-size: 24px;"><br></span></font></span></p><p style="text-align: center; line-height: 0.5;"><span style="font-size: 130px;">network</span></p>', '<p><font color="#f58220"><span style="font-size: 24px;">Being</span></font><span style="font-size: 18px;"> a partner of CSI Group means that you uncover so much new opportunities to be able to develop yourself. Here, each partner will get an ideal place to grow, expanding business’ wings in order to get the maximum results <span style="font-size: 24px;">desired</span></span></p>', '', '2016-09-24 16:34:22', '2016-09-30 21:35:30', 'Network', 'public/images/background/home_family4.png'),
(6, 6, '<p style="line-height: 0.3;"><span style="font-size: 24px;"><font color="#f58220">we provide not only hospitality</font></span></p><p style="line-height: 0.3;"><span style="font-size: 45px;"><font color="#f58220"><span style="font-size: 24px;">and flexible but also</span></font></span></p><p style="line-height: 0.3;"><span style="font-size: 45px;"><font color="#f58220"><span style="font-size: 24px;"><br></span></font></span></p><p style="text-align: center; line-height: 0.5;"><span style="font-size: 130px;">simplicity</span></p>', '<p><font color="#f58220"><span style="font-size: 24px;">Bersama</span></font><span style="font-size: 18px;"> CSI Group, Anda akan menemukan kenyamanan dan keamanan yang khas terdapat dalam keluarga. Kami akan menggandeng Anda menemukan solusi kreatif, efektif, dan efisien bagi kebutuhan mendasar marketing komunikasi, sampai pada perkara terperinci bagaimana kami menghidangkan layanan pengawasan “real time” 24 jam per hari.</span></p>', '', '2016-09-24 16:40:53', '2016-09-30 21:35:51', 'Simplicity', 'public/images/background/home_family5.png'),
(7, 11, '<p>Strategic planning aims to build an authentic and aggressive action plan in order to maintain and build competitive advantage over the competition.</p><p>The action plan will always derive from a deep analysis of three pillars, i.e. understanding the market, consumer behavior, and competitive landscape.</p><div><br></div>', '<p>desc</p>', 'public/images/featured/service1.png', '2016-09-25 07:22:53', '2016-09-25 07:22:53', 'Stratgic Planning', ''),
(8, 11, '<p>Digital media are the most rapidly increasing media nowadays. It is also more targeted and measurable. Mastering in this area is a must in the advertising industry.</p><p>The right mix-media-strategy will provide a complete 360o coverage on each point of contact with the consumer and this will certainly increase brand equity.</p><div><br></div>', '<p>desc</p>', 'public/images/featured/service2.png', '2016-09-25 07:23:29', '2016-09-25 07:23:29', 'Digital Media', ''),
(9, 11, '<p>Since starting business in this industry, we are aware that technology is a solid foundation to build a distinctive service to our clients.</p><p>We develop and utilize the best tools and software such as: INTEAM system for both program monitoring and advertising spot on national television; SMART system to support the competition analysis; VISLOG to give a visual report and log proof, ET / EQ analysis for sponsorship decision-making.</p><div><br></div>', '<p>desc</p>', 'public/images/featured/service3.png', '2016-09-25 07:24:07', '2016-09-25 07:24:07', 'Tools & system', ''),
(10, 11, '<p>Creativity in the advertising world is not solely about making advertising material/content e.g. TVC, Radio Commercial or FA Print.</p><p>The existence of a product in the community also need ideas and innovation. One of the many ways to create innovation is by creating activities like on-ground, on-air and off-air activities which could be created in the form of built-in, sponsorship, quiz, or by combining it with other media (in addition to television).</p><p><br></p><p>The goal of these activities is to create consumer’s brand experience, trial, and purchase. The other effective way to create innovation is to engage more with the community in order to get closer to the consumer’s environment e.g. Out of Home and In Store Advertising.</p><div><br></div>', '<p>desc</p>', 'public/images/featured/service4.png', '2016-09-25 07:24:37', '2016-09-25 07:24:37', 'Activation & Creative Media', ''),
(12, 9, '<p><font color="#ff9c00">Here''s the domestic institution with international class</font></p>', '<p>by specializing in the field of proffesional media, csi has more than 40 advertirers with the billing average of 350 bios</p>', 'public/images/featured/csi.png', '2016-09-30 22:48:07', '2016-09-30 23:31:22', 'CSI', ''),
(13, 9, '<p><font color="#f58220"><span style="font-size: 24px;">We</span></font>, a batch of young interdisciplinary professionals incorporated in the ‘CSI Group’, create the deep meaning of the family as the root which keep on guarding the identity of the growth of the tree of life.</p><p><br></p><p>Treating the spirit, motivation, and the motion guides and vitality in inventing. For us, client is more than just our partner. Client is a family, a place where success and happiness become the sole purpose of joint.</p><p><br></p><p>‘CSI Group’ is griya, a home for those who always being optimistic in facing every business <span style="font-size: 24px;">opportunity</span>.</p><div><br></div>', '<p>desc</p>', '', '2016-09-30 22:48:29', '2016-09-30 23:31:43', 'We', ''),
(14, 9, '<p><font color="#f58220">With pride</font></p>', '<p>we introduce the family members of ''csi group'' who are always ready to be part of you, everytime you reach success</p>', 'public/images/featured/trilogo.png', '2016-09-30 22:55:37', '2016-09-30 23:32:03', 'Trilogo', ''),
(15, 9, '<p><font color="#f58220">supported by the proficiency in the field of media and information technology</font></p>', '<p>CGI Multimedia service is managed by multitalented natives. is ready to deliver media monitoring services, mapping and digital strategy applicationing. </p>', 'public/images/featured/cgi.png', '2016-09-30 22:57:24', '2016-09-30 23:32:18', 'CGI', ''),
(16, 9, '<p><font color="#f58220">With the complete service in the field of advertising&nbsp;</font><br></p>', '<p>Mindset has been trusted by more than 20 advertisers with the billing average of 20 BIOs<br></p>', 'public/images/featured/mindset-indonesia.png', '2016-09-30 22:58:16', '2016-09-30 23:32:37', 'Mindset', ''),
(17, 10, '<p>CEO &amp; Owner</p>', '<p>never give up, fix mistakes and keep stepping</p>', 'public/images/featured/key_people1.png', '2016-10-01 00:13:24', '2016-10-01 00:13:24', 'Said Abdullah', 'public/images/background/key_bg1.png'),
(18, 10, '<p>media director</p>', '<p>when we get together with a big family, there are many moment and unforgettable, that''s what happens every day in csi</p>', 'public/images/featured/key_people2.png', '2016-10-01 00:15:08', '2016-10-01 00:15:08', 'CH Adam', 'public/images/background/key_bg2.png'),
(19, 10, '<p>finance director</p>', '<p>do respect, humble and not underestimate each others are the key factors of success otherwise being a strong team is a must</p>', 'public/images/featured/key_people3.png', '2016-10-01 00:16:48', '2016-10-01 00:16:48', 'yosnivardi arya', 'public/images/background/key_bg3.png'),
(20, 10, '<p>associate media director</p>', '<p>keep learning whenever, wherever, all progress takes place outsode the comfort zone</p>', 'public/images/featured/key_people4.png', '2016-10-01 00:18:03', '2016-10-01 00:18:03', 'vicky dhanis wardhana', 'public/images/background/key_bg4.png'),
(21, 12, '<p>sales and marketing director of rcti</p>', '<p>"Working together with CSI, really has its own impression, seeing the family atmosphere built there, both in CSI internal itself and also for us, as the working partner, just like being ''in my own home''."</p><p><br></p><p>"Hopefully CSI can be much better, corresponding with its vision and mission, which is to become a world-class agency while steadily "</p>', 'public/images/featured/testimoni1.png', '2016-10-01 02:35:59', '2016-10-01 02:35:59', 'Tantan Sumartana', ''),
(22, 13, '<p>headline</p>', '<p>desc</p>', 'public/images/featured/rcti.png', '2016-10-01 03:10:09', '2016-10-01 03:10:09', 'RCTI', ''),
(23, 13, '<p>head</p>', '<p>desc</p>', 'public/images/featured/sctv.png', '2016-10-01 03:10:26', '2016-10-01 03:10:26', 'SCTV', '');

-- --------------------------------------------------------

--
-- Table structure for table `content_abouts`
--

DROP TABLE IF EXISTS `content_abouts`;
CREATE TABLE IF NOT EXISTS `content_abouts` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `content_abouts`
--

TRUNCATE TABLE `content_abouts`;
-- --------------------------------------------------------

--
-- Table structure for table `content_homes`
--

DROP TABLE IF EXISTS `content_homes`;
CREATE TABLE IF NOT EXISTS `content_homes` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(11) NOT NULL,
  `headline` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `content_homes`
--

TRUNCATE TABLE `content_homes`;
--
-- Dumping data for table `content_homes`
--

INSERT INTO `content_homes` (`id`, `page_id`, `headline`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 7, 'Our Family', 'This is our family', '', NULL, NULL),
(2, 7, 'Together We Can', 'We are the best team to take you to the better World', '', NULL, NULL),
(3, 0, '<p>test lagi</p>', '<p>lagi</p>', '', '2016-09-20 16:14:20', '2016-09-20 16:17:18');

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
`id` int(10) unsigned NOT NULL,
  `path` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `galleries`
--

TRUNCATE TABLE `galleries`;
--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `path`, `created_at`, `updated_at`) VALUES
(1, 'public/images/featured/IMG-20150104-WA0013.jpg', '2016-09-22 08:15:39', '2016-09-22 08:15:39'),
(2, 'public/images/featured/IMG-20140807-WA0028.jpg', '2016-09-22 08:16:39', '2016-09-22 08:16:39'),
(3, 'public/images/featured/7ae8e282-4300-4754-b68b-651f0d990656.jpg', '2016-09-22 08:50:41', '2016-09-22 08:50:41'),
(4, 'public/images/featured/161113cc-f7e6-4f8b-9260-59e3808ce457.jpg', '2016-09-22 08:51:02', '2016-09-22 08:51:02'),
(5, 'public/images/featured/ais.png', '2016-09-23 15:54:57', '2016-09-23 15:54:57'),
(6, 'public/images/featured/IMG-20140807-WA0024.jpg', '2016-09-24 06:39:08', '2016-09-24 06:39:08'),
(7, 'public/images/featured/Home-Family_02.png', '2016-09-24 06:40:47', '2016-09-24 06:40:47');

-- --------------------------------------------------------

--
-- Table structure for table `infos`
--

DROP TABLE IF EXISTS `infos`;
CREATE TABLE IF NOT EXISTS `infos` (
`id` int(10) unsigned NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  `fax` text COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `longitude` text COLLATE utf8_unicode_ci NOT NULL,
  `latitude` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `infos`
--

TRUNCATE TABLE `infos`;
--
-- Dumping data for table `infos`
--

INSERT INTO `infos` (`id`, `name`, `address`, `phone`, `fax`, `image`, `longitude`, `latitude`, `created_at`, `updated_at`) VALUES
(1, 'PT Citra Surya Indonesia', '<p>Jl. Duren Tiga No. 29 A.\r\n</p><p>Pancoran Jakarta Selatan 12760\r\n</p><p>Indonesia</p>', '021-7940515', '021-7940862', 'public/images/logo/csi.png', '106.83410167694092', '-6.254042464648883', '2016-10-01 23:39:33', '2016-10-02 04:01:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `migrations`
--

TRUNCATE TABLE `migrations`;
--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2016_09_03_053234_create_pages_table', 2),
('2016_09_07_084306_alter_pages_add_template_column', 3),
('2016_09_08_042647_alter_pages_add_order_columns', 3),
('2016_09_08_062844_create_posts_table', 3),
('2016_09_14_044312_alter_users_add_lats_login_at_column', 4),
('2016_09_15_063150_alter_pages_add_hidden_column', 4),
('2016_09_15_065242_alter_pages_add_image_column', 4),
('2016_09_16_063656_create_content_homes_table', 4),
('2016_09_16_063704_create_content_abouts_table', 4),
('2016_09_21_140642_create_content_table', 5),
('2016_09_21_141711_create_contents_table', 6),
('2016_09_21_150620_alter_contents_add_title_column', 7),
('2016_09_21_151547_alter_contents_change_headline_column', 8),
('2016_09_21_152201_alter_contents_change_description_column', 9),
('2016_09_21_152437_alter_contents_change_description2_column', 10),
('2016_09_22_140424_create_gallery_table', 11),
('2016_09_22_151416_create_galleries_table', 12),
('2016_10_01_035132_alter_table_content_add_column_background', 13),
('2016_10_02_055322_create_table_contacts', 14);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `pages`
--

TRUNCATE TABLE `pages`;
--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `name`, `uri`, `type`, `content`, `created_at`, `updated_at`, `template`, `parent_id`, `lft`, `rgt`, `depth`, `hidden`, `image`) VALUES
(6, 'Home', 'Home', '/#home', 1, '<span style="font-size: 18px;"><b>test</b></span>', '2016-09-19 05:59:48', '2016-09-30 22:27:00', NULL, NULL, 1, 2, 0, 0, ''),
(9, 'About Us', 'about-us', '/#about-us', 1, '<p>replaced by template</p>', '2016-09-21 07:25:18', '2016-09-30 21:45:51', NULL, NULL, 3, 4, 0, 0, 'public/images/featured/about.png'),
(10, 'Key People', 'key-people', '/#key-people', 1, '<p>replaced by template</p>', '2016-09-21 07:25:48', '2016-09-21 07:25:48', NULL, NULL, 5, 6, 0, 0, ''),
(11, 'Service', 'service', '/#service', 1, '<p>replaced by template </p>', '2016-09-21 07:26:15', '2016-09-25 06:56:55', NULL, NULL, 7, 8, 0, 0, 'public/images/featured/service.png'),
(12, 'Testimoni', 'testimoni', '/#testimoni', 1, '<p>replaced by template</p>', '2016-09-21 07:26:43', '2016-10-01 02:41:19', NULL, NULL, 9, 10, 0, 0, 'public/images/featured/testimoni_bg1.png'),
(13, 'Our Client', 'our-client', '/#our-client', 1, '<p>replaced by template</p>', '2016-09-21 07:27:10', '2016-10-01 03:06:35', NULL, NULL, 11, 12, 0, 0, 'public/images/featured/client-bg.png'),
(14, 'Contact Us', 'contact-us', '/#contact-us', 1, '<p>replaced by template</p>', '2016-09-21 07:27:36', '2016-09-21 07:27:36', NULL, NULL, 13, 14, 0, 0, ''),
(15, 'Index', 'index', '/', 0, '<p>replaced by template</p>', '2016-09-30 22:26:31', '2016-09-30 22:26:43', 'home', NULL, 15, 16, 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `password_resets`
--

TRUNCATE TABLE `password_resets`;
-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
`id` int(10) unsigned NOT NULL,
  `author_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `posts`
--

TRUNCATE TABLE `posts`;
--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `author_id`, `title`, `slug`, `body`, `excerpt`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'Example Post 1', 'example-post-1', 'This is an example post', '', '2016-09-19 05:58:51', NULL, NULL),
(2, 2, 'Example Post 2', 'example-post-2', 'This is an example post', '', '2016-10-03 05:58:51', NULL, NULL),
(3, 1, 'Example Post 3', 'example-post-3', 'This is an example post', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `last_login_at`) VALUES
(1, 'Fakhri', 'fakhri1804@gmail.com', '$2y$10$WtZhkjaHU2eEMshxsqO6PeGDbk3l0932niVCO64MZw1RNp.8nvuLq', NULL, NULL, NULL, NULL),
(2, 'Farwah', 'farwahaliyah@gmail.com', '$2y$10$Vq4xcpeXZD5dqTUFKz9ezu1GdsKyLXGI6LNzmLtmVJiltcUqlpg1m', NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content_abouts`
--
ALTER TABLE `content_abouts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content_homes`
--
ALTER TABLE `content_homes`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `infos`
--
ALTER TABLE `infos`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `pages_uri_unique` (`uri`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `content_abouts`
--
ALTER TABLE `content_abouts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `content_homes`
--
ALTER TABLE `content_homes`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `infos`
--
ALTER TABLE `infos`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
